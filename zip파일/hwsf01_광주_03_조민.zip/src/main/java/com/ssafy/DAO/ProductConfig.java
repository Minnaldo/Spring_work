package com.ssafy.DAO;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="com.ssafy.model")
public class ProductConfig {

}

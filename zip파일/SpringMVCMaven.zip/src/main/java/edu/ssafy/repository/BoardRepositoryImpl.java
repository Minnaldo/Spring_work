package edu.ssafy.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import edu.ssafy.util.BoardDto;

@Repository("BoardRepositoryImpl")
public class BoardRepositoryImpl implements BoardRepository {

	@Override
	public void insert(BoardDto dto) {
		
	}

	@Override
	public void update(BoardDto dto) {
		
	}

	@Override
	public void delete(String no) {
		
	}

	@Override
	public BoardDto selectOne(String no) {
		
		return null;
	}

	@Override
	public List<BoardDto> selectlist() {
		
		return null;
	}

}

package edu.ssafy.repository;

import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import edu.ssafy.dto.BoardDto;
import edu.ssafy.dto.BoardResult;

@Repository
public class BoardMybatisRepositoryImpl implements BoardRepository {

	@Autowired
	SqlSession session;

	@Override
	public void insert(BoardDto dto) throws Exception {
		session.insert("board.insert", dto);		
	}

	@Override
	public List<BoardResult> selectList() throws Exception {
		return session.selectList("board.selectList");
	}
}

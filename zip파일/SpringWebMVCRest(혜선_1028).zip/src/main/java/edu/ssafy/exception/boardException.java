package edu.ssafy.exception;

public class boardException extends Exception {
	public boardException() {
		super();
	}
	public boardException(String msg)  {
		super(msg);
	}
}

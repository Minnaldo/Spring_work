package edu.ssafy.food;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootWebSafefoodApplicationTests {

	@Test
	void contextLoads() {
	}

}

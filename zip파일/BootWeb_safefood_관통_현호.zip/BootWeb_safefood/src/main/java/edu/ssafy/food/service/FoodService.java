package edu.ssafy.food.service;

public interface FoodService {

}

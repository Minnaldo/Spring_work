package edu.ssafy.food;

  import org.springframework.context.annotation.ComponentScan; import
  org.springframework.context.annotation.Configuration;  
  import javax.sql.DataSource;
  
  import org.springframework.context.annotation.Bean; import
  org.springframework.context.annotation.ComponentScan; import
  org.springframework.context.annotation.Configuration;
  
  @Configuration
  
  @ComponentScan({"edu.ssafy"}) public class WebConfig {
//  
//  @Bean public DataSource getDataSource() { BasicDataSource ds = new
//  BasicDataSource(); ds } }
//  
//  
//  @Configuration
//  
//  @ComponentScan({ "edu.ssafy" }) public class WebConfig {
//  
  }
 
package edu.ssafy.boot;

import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BootWebApplicationTests {

	@Test
	void contextLoads() {
	}

}

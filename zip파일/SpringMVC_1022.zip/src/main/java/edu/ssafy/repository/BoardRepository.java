package edu.ssafy.repository;

public interface BoardRepository {

}

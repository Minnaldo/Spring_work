package edu.ssafy.service;

public interface BoardService {

}
